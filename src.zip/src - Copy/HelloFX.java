import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.text.Text;
import java.util.Calendar;
import java.util.GregorianCalendar;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;

class Clockpane extends Pane {
    private int hour;
    private int minute;
    private int second;

    // Three new Boolean properties
    private final BooleanProperty hourHandVisible = new SimpleBooleanProperty(true);
    private final BooleanProperty minuteHandVisible = new SimpleBooleanProperty(true);
    private final BooleanProperty secondHandVisible = new SimpleBooleanProperty(true);

    // Default clock pane dimensions
    private double w = 250, h = 250;

    /** Construct a default clock with the current time */
    public Clockpane() {
        setCurrentTime();
    }

    /** Construct a clock with specified hour, minute, and second */
    public Clockpane(int hour, int minute, int second) {
        this.hour = hour;
        this.minute = minute;
        this.second = second;
        paintClock();
    }

    /* --- Accessor, Mutator, and Property Methods for Hand Visibility --- */

    public boolean isHourHandVisible() {
        return hourHandVisible.get();
    }

    public void setHourHandVisible(boolean visible) {
        this.hourHandVisible.set(visible);
        paintClock(); // Refresh UI on state change
    }

    public BooleanProperty hourHandVisibleProperty() {
        return hourHandVisible;
    }

    public boolean isMinuteHandVisible() {
        return minuteHandVisible.get();
    }

    public void setMinuteHandVisible(boolean visible) {
        this.minuteHandVisible.set(visible);
        paintClock(); 
    }

    public BooleanProperty minuteHandVisibleProperty() {
        return minuteHandVisible;
    }

    public boolean isSecondHandVisible() {
        return secondHandVisible.get();
    }

    public void setSecondHandVisible(boolean visible) {
        this.secondHandVisible.set(visible);
        paintClock(); 
    }

    public BooleanProperty secondHandVisibleProperty() {
        return secondHandVisible;
    }

    /* --- Core Clock Logic and Time Setters --- */

    public int getHour() { return hour; }
    public void setHour(int hour) { this.hour = hour; paintClock(); }

    public int getMinute() { return minute; }
    public void setMinute(int minute) { this.minute = minute; paintClock(); }

    public int getSecond() { return second; }
    public void setSecond(int second) { this.second = second; paintClock(); }

    public double getW() { return w; }
    public void setW(double w) { this.w = w; paintClock(); }

    public double getH() { return h; }
    public void setH(double h) { this.h = h; paintClock(); }

    public void setCurrentTime() {
        Calendar calendar = new GregorianCalendar();
        this.hour = calendar.get(Calendar.HOUR_OF_DAY);
        this.minute = calendar.get(Calendar.MINUTE);
        this.second = calendar.get(Calendar.SECOND);
        paintClock(); 
    }

    /** UI Paint routine evaluating hand flags before rendering */
    protected void paintClock() {
        double currentWidth = getWidth();
        double currentHeight = getHeight();
        if (currentWidth > 0) w = currentWidth;
        if (currentHeight > 0) h = currentHeight;

        double clockRadius = Math.min(w, h) * 0.8 * 0.5;
        double centerX = w / 2;
        double centerY = h / 2;

        // Base clock face construction
        Circle circle = new Circle(centerX, centerY, clockRadius);
        circle.setFill(Color.WHITE);
        circle.setStroke(Color.BLACK);
        
        Text t1 = new Text(centerX - 5, centerY - clockRadius + 12, "12");
        Text t2 = new Text(centerX - clockRadius + 3, centerY + 5, "9");
        Text t3 = new Text(centerX + clockRadius - 10, centerY + 5, "3");
        Text t4 = new Text(centerX - 3, centerY + clockRadius - 3, "6");

        getChildren().clear();
        getChildren().addAll(circle, t1, t2, t3, t4);

        // Render second hand only if true
        if (isSecondHandVisible()) {
            double sLength = clockRadius * 0.8;
            double secondX = centerX + sLength * Math.sin(second * (2 * Math.PI / 60));
            double secondY = centerY - sLength * Math.cos(second * (2 * Math.PI / 60));
            Line sLine = new Line(centerX, centerY, secondX, secondY);
            sLine.setStroke(Color.RED);
            getChildren().add(sLine);
        }

        // Render minute hand only if true
        if (isMinuteHandVisible()) {
            double mLength = clockRadius * 0.65;
            double xMinute = centerX + mLength * Math.sin(minute * (2 * Math.PI / 60));
            double yMinute = centerY - mLength * Math.cos(minute * (2 * Math.PI / 60));
            Line mLine = new Line(centerX, centerY, xMinute, yMinute);
            mLine.setStroke(Color.BLUE);
            getChildren().add(mLine);
        }

        // Render hour hand only if true
        if (isHourHandVisible()) {
            double hLength = clockRadius * 0.5;
            double xHour = centerX + hLength * Math.sin((hour % 12 + minute / 60.0) * (2 * Math.PI / 12));
            double yHour = centerY - hLength * Math.cos((hour % 12 + minute / 60.0) * (2 * Math.PI / 12));
            Line hLine = new Line(centerX, centerY, xHour, yHour);
            hLine.setStroke(Color.GREEN);
            getChildren().add(hLine);
        }
    }

    @Override
    public void setWidth(double width) {
        super.setWidth(width);
        paintClock();
    }

    @Override
    public void setHeight(double height) {
        super.setHeight(height);
        paintClock();
    }
}


public class HelloFX extends Application {
    @Override
    public void start(Stage primaryStage) {
        // Create the modified clock pane
        Clockpane clock = new Clockpane();

        // Create UI CheckBoxes for toggling visibility
        CheckBox chkHour = new CheckBox("Hour Hand");
        CheckBox chkMinute = new CheckBox("Minute Hand");
        CheckBox chkSecond = new CheckBox("Second Hand");

        // Set initial states to match the clock defaults
        chkHour.setSelected(true);
        chkMinute.setSelected(true);
        chkSecond.setSelected(true);

        // Bind checkboxes to the properties using the mutator methods
        chkHour.setOnAction(e -> clock.setHourHandVisible(chkHour.isSelected()));
        chkMinute.setOnAction(e -> clock.setMinuteHandVisible(chkMinute.isSelected()));
        chkSecond.setOnAction(e -> clock.setSecondHandVisible(chkSecond.isSelected()));

        // Layout checkboxes at the bottom
        HBox hBox = new HBox(15);
        hBox.getChildren().addAll(chkHour, chkMinute, chkSecond);
        hBox.setAlignment(Pos.CENTER);
        hBox.setStyle("-fx-padding: 10px;");

        // Main layout arrangement
        BorderPane pane = new BorderPane();
        pane.setCenter(clock);
        pane.setBottom(hBox);

        // Window scene creation
        Scene scene = new Scene(pane, 300, 320);
        primaryStage.setTitle("Interactive ClockPane");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    public static void main(String[] args) {
        launch(args);
    }
}

